function formulir(objek,nis,nama,nilai){
    document.writeln(objek);
    document.writeln("Nis       : "+nis);
    document.writeln("Nama      : "+nama);
    document.writeln("Nilai     : "+nilai);
}
objek1 = new formulir("<pre>Data Objek 1",11301,"Angga",90)
objek2 = new formulir("<pre>Data Objek 2",11302,"Cita",80)
objek3 = new formulir("<pre>Data Objek 3",11303,"Reni",100)